# import json
# import re
import math
from flask import Flask,jsonify, render_template, render_template_string,request,Response
import pymongo
from tabulate import tabulate
from bson import ObjectId 
# from pymongo import MongoClient

myclient = pymongo.MongoClient("mongodb://localhost:27017")
mydb = myclient["Amazon"]
amazonproductscollection = mydb["Products"]
app = Flask(__name__)
@app.route("/", methods=["GET"])
def home():
    return "<h1 style='text-align: center'>Welcome to ADB Amazon Products <h1>"

@app.route("/products/", methods=["GET"])
def get_all_amazon_products():
    try:
        results = amazonproductscollection.find()
        response_data = [{key: value for key, value in data.items() if key != "_id"} for data in results]
        count = len(response_data)
        return jsonify({"count": count, "data": response_data})
    except Exception as e:
        return jsonify({"error": str(e)})
    
@app.route("/products/",methods=["POST"])
def insert_Amazon_Products():
    try:
        data = request.get_json()
        result =amazonproductscollection.insert_one(data)
        response = Response("New Products Added",status=201,mimetype='application/json')
        return response
    except Exception as ex:
        response = Response("Insert Product Error",status=500,mimetype='application/json')
        return response
    

@app.route('/products/<int:code>', methods=['DELETE'])
def delete_Amazon_Products_By_Code(code):
    try:
        amazonproductscollection.delete_one({"code": code})
        return Response("Product Deleted succesfully !", status=201, mimetype="application/json")
    except Exception as ex:
        response = Response("Product Deleted succesfully !", status=201, mimetype="application/json")
        return response
    
@app.route("/products/<int:code>",methods=['Patch'])
def update_Amazon_Product(code):
    try:
        data = request.get_json()
        product = amazonproductscollection.find_one({'code': code})
        if product:
            dbresponse = amazonproductscollection.update_one({'_id': product['_id']}, {'$set': data})
            return Response("Product has been updated successfully", status=201, mimetype='application/json')
        else:
            return Response("Product not found", status=404, mimetype='application/json')
    except Exception as ex:
        response = Response("Product Update Error!", status=500, mimetype='application/json')
        return response

    
@app.route('/products/<int:code>',methods=["Get"])
def get_Amazon_Products_By_Code(code):
    try:
        print("Code:", code)
        product = amazonproductscollection.find_one({'code': code})
        print("Product:", product)
        if product:
            output = {item: product[item] for item in product if item in ["code", "name", "main_category", "sub_category", "ratings", "actual_price", "discount_price", "no_of_ratings", "image"]}
            print("Output:", output)
            return jsonify(output)
        else:
            return jsonify({"Error": "Product Not Found"}), 404
    except Exception as ex:
        print("Error:", ex)  
        response = jsonify({"Error": "An Error Occured"})
        response.status_code = 500
        return response

if __name__ == "__main__":
    app.run(port=5002,debug=True)